/* 
 * JS for WPEC, EDD and eShop
 * 
 * AJAX not working for you? Look for the (specific) class attached to your 'add to cart' button (example: YOURCLASS)
 * The add it to the list of class selectors in the jQuery command:
 * $(".edd-add-to-cart, .wpsc_buy_button, .eshopbutton, div.cartopt p label.update input#update, .YOURCLASS").click(function(){
 * 
 */

jQuery( function( $ ) {
	var buttons = [
		".edd-add-to-cart",
		".wpsc_buy_button",
		".eshopbutton",
		"div.cartopt p label.update input#update",
		".add_to_cart_button",
		".woocommerce-cart input.minus",
		".cart_item a.remove",
		"#order_review .opc_cart_item a.remove",
		".woocommerce-cart input.plus",
		".single_add_to_cart_button"
	];

	var inputs = [
		"input.edd-item-quantity"
	];

	jQuery(document.body).on('click', buttons.join(','), function(){
		WPMenucart_Timeout();
	});

	jQuery(document.body).on('change', inputs.join(','), function(){
		WPMenucart_Timeout();
	});
		
	function WPMenucart_Timeout() {
		setTimeout( WPMenucart_Load_AJAX, 1000);
	}

	function WPMenucart_Load_AJAX() {
		var data = {
			security:	wpmenucart_ajax.nonce,
			action:		"wpmenucart_ajax",
		};

		xhr = $.ajax({
			type:		'POST',
			url:		wpmenucart_ajax.ajaxurl,
			data:		data,
			success:	function( response ) {
				$('.wpmenucartli').html( response );
			}
		});
	}
});