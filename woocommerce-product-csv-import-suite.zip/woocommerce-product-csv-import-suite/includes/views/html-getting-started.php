<div id="message" class="updated woocommerce-message wc-connect">
	<div class="squeezer">
		<h4><?php _e( '<strong>Product CSV Import Suite</strong> &#8211; Before getting started prepare your CSV files', 'woocommerce-product-csv-import-suite' ); ?></h4>

		<p class="submit"><a href="http://docs.woothemes.com/documentation/plugins/woocommerce/woocommerce-extensions/product-csv-import-suite/" class="button-primary" target="_blank"><?php _e( 'Documentation', 'woocommerce-product-csv-import-suite' ); ?></a> <a class="docs button-primary" href="<?php echo plugins_url( 'sample.csv', WC_PCSVIS_FILE ); ?>"><?php _e('Sample CSV', 'woocommerce-product-csv-import-suite'); ?></a></p>

		<p>
	</div>
</div>
