var e=document.createElement('div');
e.id='LKgOcCRpwmAj';
e.style.display='none';
document.body.appendChild(e);
