<?php

if (!defined('ABSPATH')) exit; // Exit if accessed directly


if (!class_exists('WC_Facebookcommerce_WarmConfig')) :

class WC_Facebookcommerce_WarmConfig {
  static $fb_warm_pixel_id = 277565072909428;
}

endif;
