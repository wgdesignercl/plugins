<?php
/*
Plugin Name: Elfsight Social Media Icons CC |  VestaThemes.com
Description: Increasing followers and your social networks subscribers is fast and easy with the stylish and creative Elfsight Social Icons plugin.
Plugin URI: https://elfsight.com/social-media-icons-widget/wordpress/?utm_source=markets&utm_medium=codecanyon&utm_campaign=social-media-icons&utm_content=plugin-site
Version: 1.0.1
Author: Elfsight
Author URI: https://elfsight.com/?utm_source=markets&utm_medium=codecanyon&utm_campaign=social-media-icons&utm_content=plugins-list
*/

if (!defined('ABSPATH')) exit;


require_once('core/elfsight-plugin.php');

new ElfsightPlugin(array(
    'name' => 'Social Media Icons',
    'description' => 'Increasing followers and your social networks subscribers is fast and easy with the stylish and creative Elfsight Social Icons plugin.',
    'slug' => 'elfsight-social-media-icons',
    'version' => '1.0.1',
    'text_domain' => 'elfsight-social-media-icons',
    'editor_settings' => array(
        'tabs' => array(
			array(
				'id' => 'source',
				'name' => 'Source',
				'active' => true,
			),
			array(
				'id' => 'layout',
				'name' => 'Layout',
			),
			array(
				'id' => 'style',
				'name' => 'Style',
			),
		),
		'properties' => array(
			array(
				'id' => 'items',
				'name' => 'Icons',
				'tab' => 'source',
				'type' => 'complex',
				'complex' => array(
					'properties' => array(
						array(
							'id' => 'type',
							'name' => 'Icon',
							'type' => 'select',
							'select' => array(
								'options' => array(
									array(
										'value' => '500px',
										'name' => '500px',
									),
									array(
										'value' => 'badoo',
										'name' => 'Badoo',
									),
									array(
										'value' => 'behance',
										'name' => 'Behance',
									),
									array(
										'value' => 'blogger',
										'name' => 'Blogger',
									),
									array(
										'value' => 'delicious',
										'name' => 'Delicious',
									),
									array(
										'value' => 'deviantart',
										'name' => 'Deviantart',
									),
									array(
										'value' => 'digg',
										'name' => 'Digg',
									),
									array(
										'value' => 'disqus',
										'name' => 'Disqus',
									),
									array(
										'value' => 'dribbble',
										'name' => 'Dribbble',
									),
									array(
										'value' => 'envato',
										'name' => 'Envato',
									),
									array(
										'value' => 'evernote',
										'name' => 'Evernote',
									),
									array(
										'value' => 'facebook',
										'name' => 'Facebook',
									),
									array(
										'value' => 'fb-messenger',
										'name' => 'Facebook Messenger',
									),
									array(
										'value' => 'flickr',
										'name' => 'Flickr',
									),
									array(
										'value' => 'flipboard',
										'name' => 'Flipboard',
									),
									array(
										'value' => 'forrst',
										'name' => 'Forrst',
									),
									array(
										'value' => 'foursquare',
										'name' => 'Foursquare',
									),
									array(
										'value' => 'github',
										'name' => 'Github',
									),
									array(
										'value' => 'google-plus',
										'name' => 'Google Plus',
									),
									array(
										'value' => 'instagram',
										'name' => 'Instagram',
									),
									array(
										'value' => 'lastfm',
										'name' => 'Last.fm',
									),
									array(
										'value' => 'linkedin',
										'name' => 'LinkedIn',
									),
									array(
										'value' => 'livejournal',
										'name' => 'LiveJournal',
									),
									array(
										'value' => 'email',
										'name' => 'Email',
									),
									array(
										'value' => 'myspace',
										'name' => 'Myspace',
									),
									array(
										'value' => 'odnoklassniki',
										'name' => 'Odnoklassniki',
									),
									array(
										'value' => 'periscope',
										'name' => 'Periscope',
									),
									array(
										'value' => 'pinterest',
										'name' => 'Pinterest',
									),
									array(
										'value' => 'print',
										'name' => 'Print',
									),
									array(
										'value' => 'reddit',
										'name' => 'Reddit',
									),
									array(
										'value' => 'rss',
										'name' => 'RSS',
									),
									array(
										'value' => 'sina-weibo',
										'name' => 'Sina Weibo',
									),
									array(
										'value' => 'skype',
										'name' => 'Skype',
									),
									array(
										'value' => 'slack',
										'name' => 'Slack',
									),
									array(
										'value' => 'snapchat',
										'name' => 'Snapchat',
									),
									array(
										'value' => 'soundcloud',
										'name' => 'SoundCloud',
									),
									array(
										'value' => 'spotify',
										'name' => 'Spotify',
									),
									array(
										'value' => 'stackoverflow',
										'name' => 'Stack Overflow',
									),
									array(
										'value' => 'stumbleupon',
										'name' => 'StumbleUpon',
									),
									array(
										'value' => 'telegram',
										'name' => 'Telegram',
									),
									array(
										'value' => 'tumblr',
										'name' => 'Tumblr',
									),
									array(
										'value' => 'twitter',
										'name' => 'Twitter',
									),
									array(
										'value' => 'viadeo',
										'name' => 'Viadeo',
									),
									array(
										'value' => 'viber',
										'name' => 'Viber',
									),
									array(
										'value' => 'vimeo',
										'name' => 'Vimeo',
									),
									array(
										'value' => 'vine',
										'name' => 'Vine',
									),
									array(
										'value' => 'vk',
										'name' => 'Vk',
									),
									array(
										'value' => 'whatsapp',
										'name' => 'WhatsApp',
									),
									array(
										'value' => 'xing',
										'name' => 'Xing',
									),
									array(
										'value' => 'youtube',
										'name' => 'YouTube',
									),
								),
							),
							'defaultValue' => '',
							'description' => 'Choose the icon to display from the list. If you can\'t find the icon you\'re looking for, email us at support@elfsight.com',
						),
						array(
							'id' => 'url',
							'name' => 'URL',
							'type' => 'text',
							'defaultValue' => '',
							'description' => 'Enter the target page URL here. Clicking on an icon will open this page in a new browser tab.',
						),
					),
				),
				'allowEmpty' => true,
				'defaultValue' => array(
					array(
						'type' => 'facebook',
						'url' => 'https://www.facebook.com/elfsight',
					),
					array(
						'type' => 'twitter',
						'url' => 'https://twitter.com/elfsight',
					),
					array(
						'type' => 'instagram',
						'url' => 'https://www.instagram.com/elfsight/',
					),
					array(
						'type' => 'email',
						'url' => 'mailto:hello@elfsight.com',
					),
				),
				'description' => 'Select the social icons you want to display on your webpage. If you can\'t find the icon you\'re looking for, email us at support@elfsight.com',
			),
			array(
				'id' => 'size',
				'name' => 'Icon size',
				'tab' => 'layout',
				'type' => 'select-inline',
				'selectInline' => array(
					'options' => array(
						array(
							'value' => '24',
							'name' => '24px',
						),
						array(
							'value' => '32',
							'name' => '32px',
						),
						array(
							'value' => '40',
							'name' => '40px',
						),
						array(
							'value' => '48',
							'name' => '48px',
						),
						array(
							'value' => '60',
							'name' => '60px',
						),
					),
				),
				'defaultValue' => '32',
				'description' => 'Select icon size from the list.',
			),
			array(
				'id' => 'style',
				'name' => 'Style',
				'tab' => 'style',
				'type' => 'select',
				'select' => array(
					'options' => array(
						array(
							'value' => 'default',
							'name' => 'Default',
						),
						array(
							'value' => 'material',
							'name' => 'Material',
						),
						array(
							'value' => 'flat',
							'name' => 'Flat',
						),
						array(
							'value' => 'classic',
							'name' => 'Classic',
						),
						array(
							'value' => 'bordered',
							'name' => 'Bordered',
						),
						array(
							'value' => 'symbol',
							'name' => 'Symbol',
						),
					),
				),
				'defaultValue' => 'default',
				'description' => 'Select the appropriate icon look from the list.',
			),
			array(
				'id' => 'colorsSubgroup',
				'name' => 'Colors',
				'tab' => 'style',
				'type' => 'subgroup',
				'subgroup' => array(
					'properties' => array(
						array(
							'id' => 'iconColor',
							'name' => 'Icon color',
							'tab' => 'style',
							'type' => 'select-inline',
							'selectInline' => array(
								'options' => array(
									array(
										'value' => 'native',
										'name' => 'Native',
									),
									array(
										'value' => 'black',
										'name' => 'Black',
									),
									array(
										'value' => 'white',
										'name' => 'White',
									),
								),
							),
							'defaultValue' => 'white',
							'description' => 'Choose the color of the icon symbol. Three colors are available: native - is in icon brand color, you can also choose black or white.',
						),
						array(
							'id' => 'bgColor',
							'name' => 'Background color',
							'tab' => 'style',
							'type' => 'select-inline',
							'selectInline' => array(
								'options' => array(
									array(
										'value' => 'native',
										'name' => 'Native',
									),
									array(
										'value' => 'black',
										'name' => 'Black',
									),
									array(
										'value' => 'white',
										'name' => 'White',
									),
								),
							),
							'defaultValue' => 'native',
							'description' => 'Choose the icon background color. Three colors are available: native - is in icon brand color, you can also choose black or white. This option doesn\'t work with "bordered" and "symbol" styles.',
						),
						array(
							'id' => 'iconColorOnHover',
							'name' => 'Hover: icon color',
							'tab' => 'style',
							'type' => 'select-inline',
							'selectInline' => array(
								'options' => array(
									array(
										'value' => 'native',
										'name' => 'Native',
									),
									array(
										'value' => 'black',
										'name' => 'Black',
									),
									array(
										'value' => 'white',
										'name' => 'White',
									),
								),
							),
							'defaultValue' => 'white',
							'description' => 'Choose the icon symbol color on hover. The predefined options are the same as for the "Icon color" option.',
						),
						array(
							'id' => 'bgColorOnHover',
							'name' => 'Hover: background color',
							'tab' => 'style',
							'type' => 'select-inline',
							'selectInline' => array(
								'options' => array(
									array(
										'value' => 'native',
										'name' => 'Native',
									),
									array(
										'value' => 'black',
										'name' => 'Black',
									),
									array(
										'value' => 'white',
										'name' => 'White',
									),
								),
							),
							'defaultValue' => 'native',
							'description' => 'Choose the icon background color on hover. The predefined options are the same as for the "Background color" option.',
						),
					),
				),
			),
			array(
				'id' => 'borderRadius',
				'name' => 'Border radius',
				'tab' => 'style',
				'type' => 'select-inline',
				'selectInline' => array(
					'options' => array(
						array(
							'value' => 'circle',
							'name' => 'Circle',
						),
						array(
							'value' => 'rounded',
							'name' => 'Rounded',
						),
						array(
							'value' => 'square',
							'name' => 'Square',
						),
					),
				),
				'defaultValue' => 'circle',
				'description' => 'Choose your border radius - circle, rounded, square.',
			),
			array(
				'id' => 'animation',
				'name' => 'Animation',
				'tab' => 'style',
				'type' => 'select',
				'select' => array(
					'options' => array(
						array(
							'value' => 'none',
							'name' => 'None',
						),
						array(
							'value' => 'bounce',
							'name' => 'Bounce',
						),
						array(
							'value' => 'fly',
							'name' => 'Fly',
						),
						array(
							'value' => 'rotate',
							'name' => 'Rotate',
						),
						array(
							'value' => 'slide',
							'name' => 'Slide',
						),
						array(
							'value' => 'zoom',
							'name' => 'Zoom',
						),
					),
				),
				'defaultValue' => 'bounce',
				'description' => 'Choose one of the animation styles to play on hover.',
			),
			array(
				'id' => 'transparencySubgroup',
				'name' => 'Transparency',
				'tab' => 'style',
				'type' => 'subgroup',
				'subgroup' => array(
					'properties' => array(
						array(
							'id' => 'transparency',
							'name' => 'Transparency, %',
							'tab' => 'style',
							'type' => 'number',
							'defaultValue' => 100,
							'description' => 'Set the icon transparency percentage. Use this option to make the icons fit your website`s design.',
						),
						array(
							'id' => 'transparencyOnHover',
							'name' => 'Transparency on hover, %',
							'tab' => 'style',
							'type' => 'number',
							'defaultValue' => 100,
							'description' => 'Set the icon transparency percentage on hover. Use this option to make the icons fit your website`s design.',
						),
					),
				),
			),
		),
    ),
    'editor_preferences' => array(
        'previewUpdateTimeout' => 0
    ),
    'script_url' => plugins_url('assets/elfsight-social-media-icons.js', __FILE__),

    'plugin_name' => 'Elfsight Social Media Icons',
    'plugin_file' => __FILE__,
    'plugin_slug' => plugin_basename(__FILE__),

    'vc_icon' => plugins_url('assets/img/vc-icon.png', __FILE__),

    'menu_icon' => plugins_url('assets/img/menu-icon.png', __FILE__),
    'update_url' => 'https://a.elfsight.com/updates/',

    'preview_url' => plugins_url('preview/', __FILE__),

    'product_url' => 'https://codecanyon.net/item/wordpress-social-media-icons-social-icons-plugin/20612375?ref=Elfsight',
    'support_url' => 'https://elfsight.ticksy.com/submit/#100010704'
));

?>